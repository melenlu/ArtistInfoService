mvn spring-boot:run
#java -jar MusicArtistService-1.0.jar -log
